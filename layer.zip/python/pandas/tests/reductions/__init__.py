"""
Tests for reductions where we want to test for matching behavior across
Array, Index, Series, and DataFrame methods.
"""
